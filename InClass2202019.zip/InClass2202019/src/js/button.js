class Submit extends React.Component {
    state = {}
    render() {
        return (
            <button type="submit" className="btn btn-primary">Submit</button>
        );
    }
}